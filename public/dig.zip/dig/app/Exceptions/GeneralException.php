<?php

namespace App\Exceptions;

use Exception;

/**
 * Class GeneralException.
 */
class GeneralException extends Exception
{
}
