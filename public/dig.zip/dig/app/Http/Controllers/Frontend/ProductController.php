<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\AppBaseController;

use App\Models\Backend\Category;
use App\Models\Backend\Product;
use Illuminate\Http\Request;

/**
 * Class FrontendController.
 */
class ProductController extends AppBaseController
{
    /**
     * @return \Illuminate\View\View
     */
    public function index()
    {
        return view('frontend.products.index', compact('class_value', 'class_display_value', 'products'));
    }

    public function categories(Request $request)
    {
        //$type = $request->input('type');
        $user = access()->user();
        dd($user);
        $categories = Category::select('display_name', 'id');
        if($type) {
            $categories = $categories->where('type', $type);
        }
        $categories = $categories->get();

        return view('frontend.products.categories', compact('categories'));
    }

    /**
     * @return \Illuminate\View\View
     */
    public function create()
    {
        return view('frontend.products.create');
    }
}
