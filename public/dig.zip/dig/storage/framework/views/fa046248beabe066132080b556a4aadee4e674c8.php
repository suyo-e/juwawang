<div class="footerNav">
    <ul>
        <li>
            <a href="#">
                <img src="image/foter-nav-h.png" alt=""/>
                <p>首页</p>
            </a>
        </li>
        <li>
            <a href="#">
                <img class="foter-nav-f" src="image/foter-nav-f.png" alt=""/>
                <p>分类</p>
            </a>
        </li>
        <li>
            <a href="#">
                <img class="foter-nav-z" src="image/foter-nav-z.png" alt=""/>
                <p>咨询</p>
            </a>
        </li>
        <li>
            <a href="#">
                <img class="foter-nav-z" src="image/foter-nav-r.png" alt=""/>
                <p>我的</p>
            </a>
        </li>
    </ul>
</div>
