<?php $__env->startSection('content'); ?>
    <div class="screening">
        <ul>
            <li class="Regional" id="class-picker-li" >
                分类
                <img src="../../image/on_bottom.png" alt="">
                <input type="hidden" id="class-picker" name="class" />
            </li>
            <li class="Brand" id="city-picker-li">
                地区
                <img src="../../image/on_bottom.png" alt="">
                <input type="hidden" id="city-picker" name="city" />
            </li>
            <li class="Sort" id="time-picker-li">
                发布时间
                <img src="../../image/on_bottom.png" alt="">
                <input type="hidden" id="time-picker" name="time" />
            </li>
            <li class="Sort" id="from-picker-li">
                来源
                <img src="../../image/on_bottom.png" alt="">
                <input type="hidden" id="from-picker" name="from" />
            </li>
        </ul>
    </div>

    <div class="classContent">
      <ul>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li>
              <div class="classImg">
                  <img src="<?php echo e($product->pic_url); ?>" alt="">
              </div>
              <div class="classcont">
                  <p><b><?php echo e($product->title); ?></b></p>
                  <p>价格 : <span class="price"><?php echo e($product->price); ?> </span></p>
                  <p>经销商 : <span><?php echo e(substr($product->created_at, 0, 10)); ?></span></p>
                  <p>地址 : <span><?php echo e($product->address); ?></span></p>
              </div>
          </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
   </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php echo $__env->make('frontend.layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-weui/1.0.1/js/city-picker.min.js"></script>
<script>
$(function() {
    $("#city-picker-li").click(function() {
        setTimeout(function() {
            $("#city-picker").picker("open");
            $("#city-picker").focus();
        }, 500);
    });
    
    $("#city-picker").cityPicker({
        title: "请选择省份城市",
        showDistrict: false,
    });

    $("#class-picker-li").click(function() {
        setTimeout(function() {
            $("#class-picker").picker("open");
            $("#class-picker").focus();
        }, 500);
    });

    $("#class-picker").picker({
        title: "请选择分类",
        cols: [
            {
                textAlign: 'center',
                values: [<?php echo e($class_value); ?>],
                displayValues: [<?php echo $class_display_value; ?>]
            }
        ]
    });

    $("#time-picker-li").click(function() {
        setTimeout(function() {
            $("#time-picker").picker("open");
            $("#time-picker").focus();
        }, 500);
    });

    $("#time-picker").picker({
        title: "请选择发布时间",
        cols: [
            {
                textAlign: 'center',
                values: []
            }
        ]
    });

    $("#from-picker-li").click(function() {
        setTimeout(function() {
            $("#from-picker").picker("open");
            $("#from-picker").focus();
        }, 500);
    });

    $("#from-picker").picker({
        title: "请选择来源",
        cols: [
            {
                textAlign: 'center',
                values: ['用户', '代理商', '厂商']
            }
        ]
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>