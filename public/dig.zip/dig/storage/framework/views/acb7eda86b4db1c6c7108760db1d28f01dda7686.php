<!-- Display Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('display_name', 'Display Name:'); ?>

    <?php echo Form::text('display_name', null, ['class' => 'form-control']); ?>

</div>

<!-- Parent Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('parent_id', 'Parent Id:'); ?>

    <?php echo Form::select('parent_id', $data, null, ['class' => 'form-control']); ?>

</div>

<!-- Pic Url Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('pic_url', 'Pic Url:'); ?>

    <?php echo Form::file('pic_url'); ?>

</div>
<div class="clearfix"></div>

<!-- Type Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('type', 'Type:'); ?>

    <?php echo Form::select('type', ['0' => 'All', '1' => 'manufacturer', '2' => 'agent', '3' => 'user'], null, ['class' => 'form-control']); ?>

</div>

<!-- Url Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('url', 'Url:'); ?>

    <?php echo Form::text('url', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('admin.categories.index'); ?>" class="btn btn-default">Cancel</a>
</div>

<?php $__env->startSection('scripts'); ?>
<script>
jQuery("#parent_id").change(function() {
    if($(this).val() != 0){
        $("#type").attr('disabled', true);
        $("#type").val(0);
    }
    else {
        $("#type").attr('disabled', false);
    }
});
</script>
<?php $__env->stopSection(); ?>
