<?php $__env->startSection('content'); ?>
<div class="register">
    <form action="<?php echo e(url('/postRegister')); ?>" method="post">
    <div id="step_1">
        <input class="inputAll" type="text" name="phone" value="<?php echo e(old('phone')); ?>" placeholder=" 请输入电话号码">
        <div class="code">
            <input class="num inpt" placeholder=" 请输入验证码" type="number">
            <button class="onbtn" type="button">获取验证码</button>
        </div>
        <input class="inputAll" type="password" name="password" value="<?php echo e(old('password')); ?>" placeholder=" 请设置密码">
        <div class="Aradio">
            <label><input class="Fruit" type="radio" value="0" name="type" checked="">用户</label>
            <label><input class="Fruit" type="radio" value="1" name="type">经销商</label>
            <label><input class="Fruit" type="radio" value="2" name="type">厂家</label>
        </div>
        <div class="NextStep">
            <button type="button">下一步</button>
        </div>
        <label class="imy">
            <input type="checkbox">我已阅读并同意
            <span>《服务协议》</span>
        </label>
    </div>
    <div id="step_2" class="listManufa">
        <ul>
            <li class="">挖掘机 <img src="/image/on_right.png" alt=""> </li>
        </ul>
    </div>
    <div id="step_3">
        <input class="inputAll" type="text" name="name" value="<?php echo e(old('name')); ?>" placeholder="真实姓名">
        <br>
        <input class="inputAll" type="text" name="city_id" placeholder="地区">
        <br>
        <input class="inputAll" type="text" name="industry_name" placeholder="经销商名称或者厂商名称">
        <br>
        <a href="#"><button class="btnAll" type="submit">提交</button></a>
    </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>