<li class="treeview active">
  <a href="#">
    <i class="fa fa-edit"></i> <span>System Management</span>
    <span class="pull-right-container">
      <i class="fa fa-angle-left pull-right"></i>
    </span>
  </a>
  <ul class="treeview-menu menu-open" style="display: block;">
    <li class="<?php echo e(Request::is('users*') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('admin.access.user.index')); ?>"><i class="fa fa-circle-o"></i><span>Users</span></a>
    </li>
  </ul>
</li>

