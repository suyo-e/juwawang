<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $product->id; ?></p>
</div>

<!-- Title Field -->
<div class="form-group">
    <?php echo Form::label('title', 'Title:'); ?>

    <p><?php echo $product->title; ?></p>
</div>

<!-- Description Field -->
<div class="form-group">
    <?php echo Form::label('description', 'Description:'); ?>

    <p><?php echo $product->description; ?></p>
</div>

<!-- User Id Field -->
<div class="form-group">
    <?php echo Form::label('user_id', 'User Id:'); ?>

    <p><?php echo $product->user_id; ?></p>
</div>

<!-- Type Name Field -->
<div class="form-group">
    <?php echo Form::label('type_name', 'Type Name:'); ?>

    <p><?php echo $product->type_name; ?></p>
</div>

<!-- Category Id Field -->
<div class="form-group">
    <?php echo Form::label('category_id', 'Category Id:'); ?>

    <p><?php echo $product->category_id; ?></p>
</div>

<!-- Industry Id Field -->
<div class="form-group">
    <?php echo Form::label('industry_id', 'Industry Id:'); ?>

    <p><?php echo $product->industry_id; ?></p>
</div>

<!-- Prov Id Field -->
<div class="form-group">
    <?php echo Form::label('prov_id', 'Prov Id:'); ?>

    <p><?php echo $product->prov_id; ?></p>
</div>

<!-- City Id Field -->
<div class="form-group">
    <?php echo Form::label('city_id', 'City Id:'); ?>

    <p><?php echo $product->city_id; ?></p>
</div>

<!-- Brand Name Field -->
<div class="form-group">
    <?php echo Form::label('brand_name', 'Brand Name:'); ?>

    <p><?php echo $product->brand_name; ?></p>
</div>

<!-- Pic Url Field -->
<div class="form-group">
    <?php echo Form::label('pic_url', 'Pic Url:'); ?>

    <p><?php echo $product->pic_url; ?></p>
</div>

<!-- Price Field -->
<div class="form-group">
    <?php echo Form::label('price', 'Price:'); ?>

    <p><?php echo $product->price; ?></p>
</div>

<!-- Address Field -->
<div class="form-group">
    <?php echo Form::label('address', 'Address:'); ?>

    <p><?php echo $product->address; ?></p>
</div>

<!-- Contact Name Field -->
<div class="form-group">
    <?php echo Form::label('contact_name', 'Contact Name:'); ?>

    <p><?php echo $product->contact_name; ?></p>
</div>

<!-- Wechat Field -->
<div class="form-group">
    <?php echo Form::label('wechat', 'Wechat:'); ?>

    <p><?php echo $product->wechat; ?></p>
</div>

<!-- Qq Field -->
<div class="form-group">
    <?php echo Form::label('qq', 'Qq:'); ?>

    <p><?php echo $product->qq; ?></p>
</div>

<!-- Phone Field -->
<div class="form-group">
    <?php echo Form::label('phone', 'Phone:'); ?>

    <p><?php echo $product->phone; ?></p>
</div>

<!-- View Count Field -->
<div class="form-group">
    <?php echo Form::label('view_count', 'View Count:'); ?>

    <p><?php echo $product->view_count; ?></p>
</div>

<!-- Collect Count Field -->
<div class="form-group">
    <?php echo Form::label('collect_count', 'Collect Count:'); ?>

    <p><?php echo $product->collect_count; ?></p>
</div>

<!-- Banner Urls Field -->
<div class="form-group">
    <?php echo Form::label('banner_urls', 'Banner Urls:'); ?>

    <p><?php echo $product->banner_urls; ?></p>
</div>

<!-- Status Field -->
<div class="form-group">
    <?php echo Form::label('status', 'Status:'); ?>

    <p><?php echo $product->status; ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $product->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $product->updated_at; ?></p>
</div>

