<!-- Main Footer -->
<footer class="main-footer">
    <!-- Default to the left -->
    <strong>Copyright &copy; <?php echo e(date('Y')); ?> <a href="#"><?php echo e(app_name()); ?></a>.</strong> <?php echo e(trans('strings.backend.general.all_rights_reserved')); ?>

</footer>
