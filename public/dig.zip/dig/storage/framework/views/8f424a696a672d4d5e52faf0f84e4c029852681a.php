

<li class="<?php echo e(Request::is('orders*') ? 'active' : ''); ?>">
    <a href="<?php echo route('admin.orders.index'); ?>"><i class="fa fa-circle-o"></i><span>Orders</span></a>
</li>

<li class="<?php echo e(Request::is('collects*') ? 'active' : ''); ?>">
    <a href="<?php echo route('admin.collects.index'); ?>"><i class="fa fa-circle-o"></i><span>Collects</span></a>
</li>

<li class="<?php echo e(Request::is('industries*') ? 'active' : ''); ?>">
    <a href="<?php echo route('admin.industries.index'); ?>"><i class="fa fa-circle-o"></i><span>Industries</span></a>
</li>

<li class="<?php echo e(Request::is('categories*') ? 'active' : ''); ?>">
    <a href="<?php echo route('admin.categories.index'); ?>"><i class="fa fa-circle-o"></i><span>Categories</span></a>
</li>

<li class="<?php echo e(Request::is('banners*') ? 'active' : ''); ?>">
    <a href="<?php echo route('admin.banners.index'); ?>"><i class="fa fa-circle-o"></i><span>Banners</span></a>
</li>




<li class="<?php echo e(Request::is('profiles*') ? 'active' : ''); ?>">
    <a href="<?php echo route('admin.profiles.index'); ?>"><i class="fa fa-circle-o"></i><span>Profiles</span></a>
</li>



<li class="<?php echo e(Request::is('products*') ? 'active' : ''); ?>">
    <a href="<?php echo route('admin.products.index'); ?>"><i class="fa fa-circle-o"></i><span>Products</span></a>
</li>

