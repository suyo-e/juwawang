<?php $__env->startSection('title', trans('labels.backend.access.users.management') . ' | ' . trans('labels.backend.access.users.create')); ?>

<?php $__env->startSection('page-header'); ?>
    <h1>
        <?php echo e(trans('labels.backend.access.users.management')); ?>

        <small><?php echo e(trans('labels.backend.access.users.create')); ?></small>
    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo e(Form::open(['route' => 'admin.access.user.store', 'class' => 'form-horizontal', 'role' => 'form', 'method' => 'post'])); ?>


        <div class="box box-success">
            <div class="box-header with-border">
                <h3 class="box-title"><?php echo e(trans('labels.backend.access.users.create')); ?></h3>

                <div class="box-tools pull-right">
                    <?php echo $__env->make('backend.access.includes.partials.user-header-buttons', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div><!--box-tools pull-right-->
            </div><!-- /.box-header -->

            <div class="box-body">
                <div class="form-group">
                    <?php echo e(Form::label('name', trans('validation.attributes.backend.access.users.name'), ['class' => 'col-lg-2 control-label'])); ?>


                    <div class="col-lg-10">
                        <?php echo e(Form::text('name', null, ['class' => 'form-control', 'placeholder' => trans('validation.attributes.backend.access.users.name')])); ?>

                    </div><!--col-lg-10-->
                </div><!--form control-->

                <div class="form-group">
                    <?php echo e(Form::label('email', trans('validation.attributes.backend.access.users.email'), ['class' => 'col-lg-2 control-label'])); ?>


                    <div class="col-lg-10">
                        <?php echo e(Form::text('email', null, ['class' => 'form-control', 'placeholder' => trans('validation.attributes.backend.access.users.email')])); ?>

                    </div><!--col-lg-10-->
                </div><!--form control-->

                <div class="form-group">
                    <?php echo e(Form::label('password', trans('validation.attributes.backend.access.users.password'), ['class' => 'col-lg-2 control-label'])); ?>


                    <div class="col-lg-10">
                        <?php echo e(Form::password('password', ['class' => 'form-control', 'placeholder' => trans('validation.attributes.backend.access.users.password')])); ?>

                    </div><!--col-lg-10-->
                </div><!--form control-->

                <div class="form-group">
                    <?php echo e(Form::label('password_confirmation', trans('validation.attributes.backend.access.users.password_confirmation'), ['class' => 'col-lg-2 control-label'])); ?>


                    <div class="col-lg-10">
                        <?php echo e(Form::password('password_confirmation', ['class' => 'form-control', 'placeholder' => trans('validation.attributes.backend.access.users.password_confirmation')])); ?>

                    </div><!--col-lg-10-->
                </div><!--form control-->

                <div class="form-group">
                    <?php echo e(Form::label('status', trans('validation.attributes.backend.access.users.active'), ['class' => 'col-lg-2 control-label'])); ?>


                    <div class="col-lg-1">
                        <?php echo e(Form::checkbox('status', '1', true)); ?>

                    </div><!--col-lg-1-->
                </div><!--form control-->

                <div class="form-group">
                    <?php echo e(Form::label('confirmed', trans('validation.attributes.backend.access.users.confirmed'), ['class' => 'col-lg-2 control-label'])); ?>


                    <div class="col-lg-1">
                        <?php echo e(Form::checkbox('confirmed', '1', true)); ?>

                    </div><!--col-lg-1-->
                </div><!--form control-->

                <div class="form-group">
                    <label class="col-lg-2 control-label"><?php echo e(trans('validation.attributes.backend.access.users.send_confirmation_email')); ?><br/>
                        <small><?php echo e(trans('strings.backend.access.users.if_confirmed_off')); ?></small>
                    </label>

                    <div class="col-lg-1">
                        <?php echo e(Form::checkbox('confirmation_email', '1')); ?>

                    </div><!--col-lg-1-->
                </div><!--form control-->

                <div class="form-group">
                    <?php echo e(Form::label('status', trans('validation.attributes.backend.access.users.associated_roles'), ['class' => 'col-lg-2 control-label'])); ?>


                    <div class="col-lg-3">
                        <?php if(count($roles) > 0): ?>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input type="checkbox" value="<?php echo e($role->id); ?>" name="assignees_roles[<?php echo e($role->id); ?>]" id="role-<?php echo e($role->id); ?>" <?php echo e(is_array(old('assignees_roles')) && in_array($role->id, old('assignees_roles')) ? 'checked' : ''); ?> /> <label for="role-<?php echo e($role->id); ?>"><?php echo e($role->name); ?></label>
                                <a href="#" data-role="role_<?php echo e($role->id); ?>" class="show-permissions small">
                                    (
                                        <span class="show-text"><?php echo e(trans('labels.general.show')); ?></span>
                                        <span class="hide-text hidden"><?php echo e(trans('labels.general.hide')); ?></span>
                                        <?php echo e(trans('labels.backend.access.users.permissions')); ?>

                                    )
                                </a>
                                <br/>
                                <div class="permission-list hidden" data-role="role_<?php echo e($role->id); ?>">
                                    <?php if($role->all): ?>
                                        <?php echo e(trans('labels.backend.access.users.all_permissions')); ?><br/><br/>
                                    <?php else: ?>
                                        <?php if(count($role->permissions) > 0): ?>
                                            <blockquote class="small"><?php $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($perm->display_name); ?><br/>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </blockquote>
                                        <?php else: ?>
                                            <?php echo e(trans('labels.backend.access.users.no_permissions')); ?><br/><br/>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div><!--permission list-->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <?php echo e(trans('labels.backend.access.users.no_roles')); ?>

                        <?php endif; ?>
                    </div><!--col-lg-3-->
                </div><!--form control-->
            </div><!-- /.box-body -->
        </div><!--box-->

        <div class="box box-info">
            <div class="box-body">
                <div class="pull-left">
                    <?php echo e(link_to_route('admin.access.user.index', trans('buttons.general.cancel'), [], ['class' => 'btn btn-danger btn-xs'])); ?>

                </div><!--pull-left-->

                <div class="pull-right">
                    <?php echo e(Form::submit(trans('buttons.general.crud.create'), ['class' => 'btn btn-success btn-xs'])); ?>

                </div><!--pull-right-->

                <div class="clearfix"></div>
            </div><!-- /.box-body -->
        </div><!--box-->

    <?php echo e(Form::close()); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('after-scripts'); ?>
    <?php echo e(Html::script('js/backend/access/users/script.js')); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>