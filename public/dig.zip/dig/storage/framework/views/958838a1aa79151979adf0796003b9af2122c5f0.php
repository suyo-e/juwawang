<!-- Title Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('title', 'Title:'); ?>

    <?php echo Form::text('title', null, ['class' => 'form-control']); ?>

</div>

<!-- Description Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('description', 'Description:'); ?>

    <?php echo Form::textarea('description', null, ['class' => 'form-control']); ?>

</div>

<!-- User Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('user_id', 'User Id:'); ?>

    <?php echo Form::text('user_id', null, ['class' => 'form-control']); ?>

</div>

<!-- Type Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('type_name', 'Type Name:'); ?>

    <?php echo Form::text('type_name', null, ['class' => 'form-control']); ?>

</div>

<!-- Category Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('category_id', 'Category Id:'); ?>

    <?php echo Form::select('category_id', ['0' => 'All'], null, ['class' => 'form-control']); ?>

</div>

<!-- Industry Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('industry_id', 'Industry Id:'); ?>

    <?php echo Form::select('industry_id', ['0' => 'All'], null, ['class' => 'form-control']); ?>

</div>

<!-- Prov Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('prov_id', 'Prov Id:'); ?>

    <?php echo Form::select('prov_id', ['0' => 'All'], null, ['class' => 'form-control']); ?>

</div>

<!-- City Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('city_id', 'City Id:'); ?>

    <?php echo Form::select('city_id', ['0' => 'All'], null, ['class' => 'form-control']); ?>

</div>

<!-- Brand Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('brand_name', 'Brand Name:'); ?>

    <?php echo Form::text('brand_name', null, ['class' => 'form-control']); ?>

</div>

<!-- Pic Url Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('pic_url', 'Pic Url:'); ?>

    <?php echo Form::file('pic_url'); ?>

</div>
<div class="clearfix"></div>

<!-- Price Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('price', 'Price:'); ?>

    <?php echo Form::text('price', null, ['class' => 'form-control']); ?>

</div>

<!-- Address Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('address', 'Address:'); ?>

    <?php echo Form::textarea('address', null, ['class' => 'form-control']); ?>

</div>

<!-- Contact Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('contact_name', 'Contact Name:'); ?>

    <?php echo Form::text('contact_name', null, ['class' => 'form-control']); ?>

</div>

<!-- Wechat Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('wechat', 'Wechat:'); ?>

    <?php echo Form::text('wechat', null, ['class' => 'form-control']); ?>

</div>

<!-- Qq Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('qq', 'Qq:'); ?>

    <?php echo Form::text('qq', null, ['class' => 'form-control']); ?>

</div>

<!-- Phone Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('phone', 'Phone:'); ?>

    <?php echo Form::text('phone', null, ['class' => 'form-control']); ?>

</div>

<!-- View Count Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('view_count', 'View Count:'); ?>

    <?php echo Form::text('view_count', null, ['class' => 'form-control']); ?>

</div>

<!-- Collect Count Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('collect_count', 'Collect Count:'); ?>

    <?php echo Form::text('collect_count', null, ['class' => 'form-control']); ?>

</div>

<!-- Banner Urls Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('banner_urls', 'Banner Urls:'); ?>

    <?php echo Form::file('banner_urls'); ?>

</div>
<div class="clearfix"></div>

<!-- Status Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('status', 'Status:'); ?>

    <?php echo Form::select('status', ['0' => 'Normal', '1' => 'Off'], null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('admin.products.index'); ?>" class="btn btn-default">Cancel</a>
</div>
