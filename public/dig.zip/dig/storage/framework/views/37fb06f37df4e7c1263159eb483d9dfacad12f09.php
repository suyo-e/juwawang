<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $category->id; ?></p>
</div>

<!-- Display Name Field -->
<div class="form-group">
    <?php echo Form::label('display_name', 'Display Name:'); ?>

    <p><?php echo $category->display_name; ?></p>
</div>

<!-- Parent Id Field -->
<div class="form-group">
    <?php echo Form::label('parent_id', 'Parent Id:'); ?>

    <p><?php echo $category->parent_id; ?></p>
</div>

<!-- Pic Url Field -->
<div class="form-group">
    <?php echo Form::label('pic_url', 'Pic Url:'); ?>

    <p><?php echo $category->pic_url; ?></p>
</div>

<!-- Type Field -->
<div class="form-group">
    <?php echo Form::label('type', 'Type:'); ?>

    <p><?php echo $category->type; ?></p>
</div>

<!-- Url Field -->
<div class="form-group">
    <?php echo Form::label('url', 'Url:'); ?>

    <p><?php echo $category->url; ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $category->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $category->updated_at; ?></p>
</div>

