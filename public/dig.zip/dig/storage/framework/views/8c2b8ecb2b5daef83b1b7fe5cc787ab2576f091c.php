<?php $__env->startSection('content'); ?>
<div class="listManufa">
    <ul>
        <li><a href="#">挖掘机 <img src="../../image/on_right.png" alt=""></a></li>
        <li><a href="#">破碎锤 <img src="../../image/on_right.png" alt=""></a></li>
        <li><a href="#">挖掘机配件 <img src="../../image/on_right.png" alt=""></a></li>
        <li><a href="#">破碎锤配件 <img src="../../image/on_right.png" alt=""></a></li>
        <li><a href="#">其他工程机械设备 <img src="../../image/on_right.png" alt=""></a></li>
        <li><a href="#">维修 <img src="../../image/on_right.png" alt=""></a></li>
    </ul>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>