<div class="headTop">
    <div class="search">
        <p><img src="image/search.png" alt=""/></p>
        <input type="text" placeholder="搜索商家"/>
    </div>
    <div class="Release">
        <a href="#">发布</a>
    </div>
</div>
