<!-- Type Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('type', 'Type:'); ?>

    <label class="radio-inline">
        <?php echo Form::radio('type', "0", null); ?> admin
    </label>

    <label class="radio-inline">
        <?php echo Form::radio('type', "1", null); ?> manufacturer
    </label>

    <label class="radio-inline">
        <?php echo Form::radio('type', "2", null); ?> agent
    </label>

    <label class="radio-inline">
        <?php echo Form::radio('type', "3", null); ?> user
    </label>

</div>

<!-- User Id:unsigned:foreign,users,id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('user_id:unsigned:foreign,users,id', 'User Id:unsigned:foreign,users,id:'); ?>

    <?php echo Form::text('user_id:unsigned:foreign,users,id', null, ['class' => 'form-control']); ?>

</div>

<!-- Prov Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('prov_id', 'Prov Id:'); ?>

    <?php echo Form::select('prov_id', ['0' => 'All'], null, ['class' => 'form-control']); ?>

</div>

<!-- City Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('city_id', 'City Id:'); ?>

    <?php echo Form::select('city_id', ['0' => 'All'], null, ['class' => 'form-control']); ?>

</div>

<!-- Industry Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('industry_id', 'Industry Id:'); ?>

    <?php echo Form::select('industry_id', ['0' => 'All'], null, ['class' => 'form-control']); ?>

</div>

<!-- Industry Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('industry_name', 'Industry Name:'); ?>

    <?php echo Form::text('industry_name', null, ['class' => 'form-control']); ?>

</div>

<!-- Category Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('category_id', 'Category Id:'); ?>

    <?php echo Form::select('category_id', ['0' => 'All'], null, ['class' => 'form-control']); ?>

</div>

<!-- Service Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('service', 'Service:'); ?>

    <?php echo Form::textarea('service', null, ['class' => 'form-control']); ?>

</div>

<!-- Identity Urls Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('identity_urls', 'Identity Urls:'); ?>

    <?php echo Form::file('identity_urls'); ?>

</div>
<div class="clearfix"></div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('admin.profiles.index'); ?>" class="btn btn-default">Cancel</a>
</div>
