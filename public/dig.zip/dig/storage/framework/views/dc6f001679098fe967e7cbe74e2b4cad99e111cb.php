<?php $__env->startSection('content'); ?>
<div class="login">
    <p class="logo">
        <img src="/image/logo.jpg" alt="">
    </p>
    <?php echo e(Form::open(['route' => 'frontend.auth.login', 'class' => 'form'])); ?>

        <input class="inputAll" type="text" name="phone" value="<?php echo e(old('phone')); ?>" placeholder=" 请输入电话号码">
        <input class="inputAll" type="password" name="password" value="<?php echo e(old('password')); ?>" placeholder=" 请输入密码"><br>
        <input class="btnAll" type="submit" value="立即登录">
    <?php echo e(Form::close()); ?>

    <p class="Other">
        <span>你还没有账户？</span>
        <a class="register" href="<?php echo e(url('/register')); ?>">立即注册</a>
        <a class="forgetPwd" href="<?php echo e(url('/forget')); ?>">忘记密码</a>
    </p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>