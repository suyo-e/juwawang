<!-- Display Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('display_name', 'Display Name:'); ?>

    <?php echo Form::text('display_name', null, ['class' => 'form-control']); ?>

</div>

<!-- Url Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('url', 'Url:'); ?>

    <?php echo Form::text('url', null, ['class' => 'form-control']); ?>

</div>

<!-- Pic Url Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('pic_url', 'Pic Url:'); ?>

    <?php echo Form::file('pic_url'); ?>

</div>

<!-- Type Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('type', 'Type:'); ?>

    <?php echo Form::select('type', ['0' => 'All', '1' => 'manufacturer', '2' => 'agent', '3' => 'user'], null, ['class' => 'form-control']); ?>

</div>

<!-- Description Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('description', 'Description:'); ?>

    <?php echo Form::textarea('description', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('admin.banners.index'); ?>" class="btn btn-default">Cancel</a>
</div>
